public enum MessageType {

    CONNECT, COMMAND, BOARD, MOVE, ERROR, START_GAME, PLAYER_LIST;

    private static final long serialVersionUID = 0L;
}
